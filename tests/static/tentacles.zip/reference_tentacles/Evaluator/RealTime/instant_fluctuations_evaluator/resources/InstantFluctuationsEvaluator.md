Triggers when a change of price ( > 1%) or of volume ( > x4) from recent average happens.

The price distance from recent average is defining the evaluation.