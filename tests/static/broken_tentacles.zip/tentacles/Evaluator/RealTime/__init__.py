from octobot_tentacles_manager.api.inspector import check_tentacle_version
from octobot_commons.logging.logging_util import get_logger

if check_tentacle_version('1.2.0', 'instant_fluctuations_evaluator', 'OctoBot-Default-Tentacles'):
    try:
        from .instant_fluctuations_evaluator import *
    except Exception as e:
        get_logger('TentacleLoader').exception(e, True, f'Error when loading instant_fluctuations_evaluator: {e}')
