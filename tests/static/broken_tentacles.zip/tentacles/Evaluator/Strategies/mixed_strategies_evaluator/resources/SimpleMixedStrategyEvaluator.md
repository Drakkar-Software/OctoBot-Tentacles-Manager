SimpleMixedStrategyEvaluator is the most flexible strategy. Meant to be customized, it is using
every activated technical, social and real time evaluator, and averages the evaluation notes of
each to compute its final evaluation.

This strategy can be used to make simple trading strategies
using for example only one evaluator or more complex ones using a multi-evaluator setup.

Used time frames are 1h, 4h and 1d.

Warning: this strategy only considers evaluators computing evaluations between -1 and 1.
